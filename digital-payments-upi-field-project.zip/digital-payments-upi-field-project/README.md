# Digital Payments & UPI: Impact on Local Businesses

**Student:** Rudra Patel  
**Course:** B.Tech Computer Science Engineering  
**Project type:** College field project  
**Status:** Survey data must be filled in after real field visits.

## Overview
This project studies how Unified Payments Interface (UPI) and other digital payment methods are used by local businesses in India. It focuses on adoption, perceived benefits, common difficulties, and the continued role of cash.

## Objectives
- Understand whether local businesses accept UPI.
- Identify commonly used digital payment apps.
- Explore the benefits businesses associate with UPI.
- Record challenges such as network issues, delayed confirmations, and fraud concerns.
- Compare the role of cash and digital payments in everyday transactions.

## Suggested field method
1. Visit 10–15 local shops with permission.
2. Explain the academic purpose and ask the shopkeeper if they are willing to participate.
3. Ask the questions in `survey_questionnaire.md`.
4. Enter one response per shop in `data/survey_data.csv`.
5. Do not collect customer names, phone numbers, UPI IDs, bank details, or other sensitive information.
6. Summarize the real responses in charts and update the report/presentation.

## Repository contents
- `presentation/UPI_Field_Project.pptx` — editable 12-slide presentation.
- `report/UPI_Field_Project_Report.docx` — editable project report template.
- `survey_questionnaire.md` — interview questions for shopkeepers.
- `data/survey_data.csv` — blank data-entry template.
- `data/README.md` — data-entry notes.
- `GITHUB_UPLOAD_GUIDE.md` — steps to upload this project to GitHub.

## Important data note
No field survey has been performed as part of creating these files. The CSV is a blank template and the report/presentation identify results as pending. Replace placeholders with your own collected results. Do not present invented or illustrative figures as actual field findings.

## Suggested GitHub repository name
`digital-payments-upi-field-project`

## Conclusion
Complete the survey before writing the final findings. Conclusions should reflect the responses collected from the shops you actually visited.
