# Field Survey Questionnaire
## Digital Payments & UPI: Impact on Local Businesses

**Purpose:** Academic field project about digital payment use among local businesses.  
**Target respondents:** Shopkeepers or business owners.  
**Suggested sample:** 10–15 businesses.  
**Participation:** Voluntary. Do not record personal or financial account details.

### Questions
1. Business type (e.g., grocery, food stall, clothing, pharmacy): __________________
2. Does your business accept UPI payments? (Yes / No)
3. Which payment methods do you accept? (Cash / UPI / Debit or credit card / Other)
4. Which UPI apps do customers commonly use? (PhonePe / Google Pay / Paytm / BHIM / Other / Not sure)
5. Approximately what share of your transactions are digital? (0–25% / 26–50% / 51–75% / 76–100% / Not sure)
6. How often do customers pay using UPI? (Rarely / Sometimes / Often / Very often)
7. What is the main benefit of UPI for your business? (Convenience / Faster payment / Less cash handling / Transaction record / Other / No benefit noticed)
8. What challenges have you experienced? (Network issues / Pending or failed payments / Payment confirmation / Fraud concerns / None / Other)
9. Do you still need cash for some transactions? (Yes / No)
10. Overall, has UPI made payment collection easier? (Yes / No / Unsure)
11. Any additional comment (optional): __________________________________________

### Field notes
- Ask permission before starting.
- Do not ask for PINs, OTPs, account numbers, customer details, or UPI IDs.
- Do not photograph a person or shop without permission.
- Enter responses without personally identifying the respondent.
