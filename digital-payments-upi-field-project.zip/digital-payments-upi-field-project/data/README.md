# Survey data entry notes

Use `survey_data.csv` to record one participating business per row. The first row contains column headings.

- Use a simple respondent code such as B01, B02, B03; do not use a person's name.
- Keep answers consistent with the options in `survey_questionnaire.md`.
- If a respondent does not know an answer, use `Not sure`.
- Leave optional comments blank if none are provided.
- The file is intentionally blank. Do not treat blank values as zero or as survey findings.
