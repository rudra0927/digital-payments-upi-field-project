# GitHub Upload Guide (Mobile or Laptop)

1. Sign in at https://github.com/
2. Tap **+** and choose **New repository**.
3. Repository name: `digital-payments-upi-field-project`
4. Add a short description: `A college field project on UPI adoption and its impact on local businesses.`
5. Choose **Public** if your teacher needs to open it without signing in.
6. Select **Add a README file** only if you are creating the repository from scratch without this project's README. If you create the repository with a README, uploading this folder's README may cause a duplicate/conflict; you can instead edit the existing README or create the repository without initializing files.
7. Open the repository and choose **Add file → Upload files**.
8. Upload the contents of this folder (not just the ZIP). You can upload folders by opening them and selecting files, or upload the ZIP as an archive if your teacher accepts that format.
9. Commit the files with a message such as `Add UPI field project files`.
10. Copy the repository URL and submit it to your teacher.

Before submission:
- Complete the survey and enter actual responses in `data/survey_data.csv`.
- Update the findings and conclusion in the report and slides.
- Keep respondent information anonymous.
